package com.note;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotesManager {

	public static void main(String[] args) {
		SpringApplication.run(NotesManager.class, args);
	}
}
