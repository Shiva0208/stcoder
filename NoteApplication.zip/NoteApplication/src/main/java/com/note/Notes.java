package com.note;

public class Notes {
	private int id;
	private String notedesc;
	
	public Notes() {
	}
	
	public Notes(int id, String notedesc) {
		super();
		this.id = id;
		this.notedesc = notedesc;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNotedesc() {
		return notedesc;
	}
	public void setNotedesc(String notedesc) {
		this.notedesc = notedesc;
	}
	@Override
	public String toString() {
		return "Notes [id=" + id + ", notedesc=" + notedesc + ", getId()=" + getId() + ", getNotedesc()="
				+ getNotedesc() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
}
