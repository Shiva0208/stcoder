package com.note;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class NotesController {
	
	@Autowired
	private NotesDAO dao;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		List<Notes> listNotes = dao.getNoteList();
		model.addAttribute("listNotes", listNotes);
	    return "index";
	}
	
	@RequestMapping("/view")
	public String viewNote(Model model) {
		List<Notes> listNotes = dao.getNoteList();
		model.addAttribute("listNotes", listNotes);
	    return "view_note";
	}
	
	@RequestMapping("/add")
	public String showAddNoteForm(Model model) {
	    Notes notes = new Notes();
	    model.addAttribute("notes", notes);
	     
	    return "new_note";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(@ModelAttribute("note") Notes notes) {
	    dao.save(notes);
	     
	    return "redirect:/view";
	}
	
	
}
