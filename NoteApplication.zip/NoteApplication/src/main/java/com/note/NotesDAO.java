package com.note;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

@Repository
public class NotesDAO {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Notes> getNoteList() {
		String sql = "SELECT * FROM NOTES";

		List<Notes> listNote = jdbcTemplate.query(sql, 
				BeanPropertyRowMapper.newInstance(Notes.class));

		return listNote;
	}
	
	public void save(Notes notes) {
		int noteId = (int) Math.random();
		notes.setId(noteId);
		SimpleJdbcInsert insertActor = new SimpleJdbcInsert(jdbcTemplate);
		insertActor.withTableName("notes").usingColumns("id","notesdec");
		BeanPropertySqlParameterSource param = new BeanPropertySqlParameterSource(notes);
		
		insertActor.execute(param);		
	}
	
	public Notes get(int id) {
		String sql = "SELECT * FROM NOTES WHERE id = ?";
		Object[] args = {id};
		Notes note = jdbcTemplate.queryForObject(sql, args, BeanPropertyRowMapper.newInstance(Notes.class));
		return note;
	}
}
