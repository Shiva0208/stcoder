import React from 'react';

import './Orders.scss';

function Orders() {
  return (
    <div className="h-orders">
      <div className="h-orders__hint">Returns</div>
      <div className="h-orders__title">& Orders</div>
    </div>
  );
}

export default Orders;
