create table NOTES(
id numbers(4),
notedesc varchar2(200),
constraint PK_notes PRIMARY KEY (id)
);