package com.info.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.app.model.Patient;
import com.info.app.model.Ward;
import com.info.app.repository.WardRepository;

@Service
public class WardService {
	
	@Autowired
	private WardRepository wardRepository;
	
	@Autowired
	private PatientService patientService;

	public List<Ward> getAllWards() {
		return wardRepository.findAll();
	}

	public List<Patient> getWardPatients(Long wardId) {
		return patientService.getAllWardPatients(wardId);
	}

}
