package com.info.app.model;

public class UserRole {

}
