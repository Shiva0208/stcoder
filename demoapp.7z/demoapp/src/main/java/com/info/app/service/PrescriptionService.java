package com.info.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.app.model.Prescription;
import com.info.app.repository.PrescriptionRepository;

@Service
public class PrescriptionService {

	@Autowired
	private PrescriptionRepository prescriptionRepository;
	
	public List<Prescription> getPrescriptionByTreatment(Long treatmentId) {
		return prescriptionRepository.findByTreatmentId(treatmentId);
	}

	public Optional<Prescription> findById(Long prescriptionId) {
		return prescriptionRepository.findById(prescriptionId);
	}
	
}
