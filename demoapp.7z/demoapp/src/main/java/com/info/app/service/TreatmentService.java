package com.info.app.service;

import java.util.Arrays;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.info.app.exceptions.ApiException;
import com.info.app.model.Appointment;
import com.info.app.model.BillingItem;
import com.info.app.model.Treatment;
import com.info.app.repository.TreatmentRepository;

@Service
public class TreatmentService {
	
	@Autowired
	private TreatmentRepository repository;
	
//	@Autowired
//	private MedicineRepository medicineRepository;
//	
//	@Autowired
//	private LabTestRepository labTestRepository;
	
	@Autowired
	private AppointmentService appointmentService;
	
	public Treatment getTreatment(Long id) throws ApiException {
		try {
			return repository.findById(id).get();
		}catch (NoSuchElementException e) {
			throw new ApiException("No treatment record found by id "+id, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public List<Treatment> getAllTreatmentsByDoctorAndPatient(Long userId, Long patientId,Integer page,Integer size){
		return repository.findByPatientAndDoctor(userId, patientId, page,size);
	}
	
	public Treatment getTreatmentByAppointment(Long appointmentId){
		return repository.findByAppointment(appointmentService.getAppointmentById(appointmentId));
	}
	
	public Treatment addTreatment(Treatment newTreatment, Long appointmentId) throws ApiException {
		Appointment appointment = appointmentService.getAppointmentById(appointmentId);
		if(appointment == null) {
			throw new ApiException("Invalid appointment Id provided", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		if(repository.findByAppointment(appointment) != null) {
			throw new ApiException("Cannot perform this operation because"
					+ " treatment record already presen for this appointment.", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		newTreatment.setAppointment(appointment);
		appointment.setTreatment(newTreatment);
		
		if(newTreatment.getPrescription() != null)  {
			newTreatment.getPrescription().setTreatment(newTreatment);
			newTreatment.getPrescription().getMedications().addAll(newTreatment.getPrescription().getMedications());
			newTreatment.getPrescription().getMedications().forEach(m->{
				m.setPrescription(newTreatment.getPrescription());
			});
		}
		
		if(newTreatment.getDiagnosis() != null) {
			newTreatment.getDiagnosis().forEach(d->d.setTreatment(newTreatment));
		}
		
		if(newTreatment.getPatientLabTests() != null) {
			newTreatment.getPatientLabTests().forEach(p->p.setTreatment(newTreatment));
		}
		
		if(newTreatment.getVitalDetails() != null) {
			newTreatment.getVitalDetails().forEach(v->v.setTreatment(newTreatment));
		}
		
		if(newTreatment.getBilling() != null) {
			newTreatment.getBilling().getBillingItems().forEach(bi->bi.setBilling(newTreatment.getBilling()));
			newTreatment.getBilling().setTreatment(newTreatment);
		}
		return repository.save(newTreatment);
	}
	
	public Treatment updateTreatment(Treatment updatedTreatment, Long id) throws ApiException {
		try {
			Treatment treatment = repository.findById(id).get();
		
		if(updatedTreatment.getPrescription() != null && treatment.getPrescription() != null)  {
			treatment.getPrescription().setDate(updatedTreatment.getPrescription().getDate());
			Optional.ofNullable(updatedTreatment.getPrescription().getMedications()).ifPresent(medList -> {
				treatment.getPrescription().getMedications().clear();
				treatment.getPrescription().getMedications().addAll(medList);
				treatment.getPrescription().getMedications().forEach(m-> {
					m.setPrescription(treatment.getPrescription());
				});
			});
		}else if(updatedTreatment.getPrescription() != null && treatment.getPrescription() == null) {
			treatment.setPrescription(updatedTreatment.getPrescription());
			treatment.getPrescription().getMedications().forEach(m->m.setPrescription(updatedTreatment.getPrescription()));
		}
		
		if(updatedTreatment.getDiagnosis() != null && !updatedTreatment.getDiagnosis().isEmpty()) {
			treatment.getDiagnosis().clear();
			treatment.getDiagnosis().addAll(updatedTreatment.getDiagnosis());
			treatment.getDiagnosis().forEach(d->d.setTreatment(treatment));
		}
		if(updatedTreatment.getPatientLabTests() != null && !updatedTreatment.getPatientLabTests().isEmpty()) {
			treatment.getPatientLabTests().clear();
			treatment.getPatientLabTests().addAll(updatedTreatment.getPatientLabTests());
			treatment.getPatientLabTests().forEach(p->p.setTreatment(treatment));
		}
		
		if(updatedTreatment.getVitalDetails() != null && !updatedTreatment.getVitalDetails().isEmpty()) {
			treatment.getVitalDetails().clear();
			treatment.getVitalDetails().addAll(updatedTreatment.getVitalDetails());
			treatment.getVitalDetails().forEach(v->v.setTreatment(treatment));
		}
		
		if(updatedTreatment.getBilling() != null) {
			List<BillingItem> billingItems = updatedTreatment.getBilling().getBillingItems();
			if(treatment.getBilling()!=null) {
				treatment.getBilling().getBillingItems().clear();
				treatment.setBilling(updatedTreatment.getBilling());
				treatment.getBilling().getBillingItems().addAll(billingItems);
				treatment.getBilling().getBillingItems().forEach(bi->{
					bi.setBilling(treatment.getBilling());
				});
			} else {
				treatment.setBilling(updatedTreatment.getBilling());
				treatment.getBilling().getBillingItems().forEach(bi -> bi.setBilling(treatment.getBilling()));
			}
			
			treatment.getBilling().setTreatment(treatment);
		}
		
		return repository.saveAll(Arrays.asList(treatment)).get(0);
		}catch (Exception e) {
			throw new ApiException("No treatment found...", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public void deleteTreatment(Long id) throws ApiException {
		repository.delete(getTreatment(id));
	}

	public boolean existsById(Long treatmentId) {
		return repository.existsById(treatmentId);
	}

	public Optional<Treatment> findById(Long treatmentId) {
		return repository.findById(treatmentId);
	}

	public Treatment getTreatmentForPatient(Long patientId) {
		return repository.findByPatient(patientId);
	}

}
