package com.info.app.auth.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.auth.config.JwtUtil;
import com.info.app.auth.model.JwtRequest;
import com.info.app.auth.model.JwtResponse;
import com.info.app.auth.service.JwtUserDetailService;
import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.User;
import com.info.app.response.wrapper.UserWrapper;
import com.info.app.service.UserService;

@RestController
@CrossOrigin
public class JwtAuthenticationController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private JwtUserDetailService userDetailService;
	
	@Autowired
	private UserService userService;

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public RestResponse createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws ApiException {
			authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());
			final UserDetails userDetails = userDetailService
					.loadUserByUsername(authenticationRequest.getUsername());
			final String token = jwtUtil.generateToken(userDetails);
			User doctorInfo = userService.loadUserByUsername(authenticationRequest.getUsername());
			JwtResponse jwtResponse = new JwtResponse(token);
			jwtResponse.setUser(new UserWrapper(doctorInfo));
			return new RestResponse(jwtResponse, HttpStatus.OK);
	}

	private void authenticate(String username, String password) throws ApiException {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (Exception e) {
			throw new ApiException(e.getMessage(), HttpStatus.UNAUTHORIZED);
		}
	}
}