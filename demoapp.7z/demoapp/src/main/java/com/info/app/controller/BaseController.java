package com.info.app.controller;

public class BaseController {

}
