package com.info.app.service;

import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.app.model.Consultation;
import com.info.app.model.Patient;
import com.info.app.model.User;
import com.info.app.repository.ConsultationRepository;
import com.info.app.response.wrapper.ConsultantWrapper;
import com.info.app.response.wrapper.ReferralWrapper;

@Service
public class ConsultationServie {
	
	@Autowired
	private ConsultationRepository consultationRepository;
	
	@Autowired
	private PatientService patientService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private AppointmentService appointmentService;

	public List<Consultation> getRefferredByMe(Long doctorId) {
		return consultationRepository.getRefferedByMe(doctorId);
	}
	
	public List<Consultation> getRefferredToMe(Long doctorId) {
		return consultationRepository.getRefferedToMe(doctorId);
	}

	public void referDoctor(Long patientId, Long referByDoctorId, Long referToDoctorId) {
		Consultation consultant = new Consultation();
		User doctor = userService.getUser(referToDoctorId);
		Patient patient = null;
		try {
			patient = patientService.getPatientById(patientId);
		}catch(NoSuchElementException ex) {
			patient = new Patient();
			patient.setPatientName("Referred_By_Dr."+doctor.getName());
			patient.setAddress("Fake Address");
			patient.setAge(35);
			patient.setGender("M");
			patient.setWeight(60);
			patient.setOccupation("Fake Occupation");
			patient.setCreatedOn(new Date());
			patient.setModifiedOn(new Date());
			patient = patientService.savePatient(patient);
		}
		consultant.setPatient(patient);
		consultant.setRefferedBy(userService.getUser(referByDoctorId));
		consultant.setRefferedTo(doctor);
		consultant.setCreatedOn(new Date());
		consultant.setModifiedOn(new Date());
		consultationRepository.save(consultant);
		createAnAppointment(referToDoctorId,patient.getId());
	}
	
	public ConsultantWrapper getAllConsultations(Long doctorId) {
		ConsultantWrapper consultationWrapper = new ConsultantWrapper();
		List<Consultation> referredByMeList = getRefferredByMe(doctorId);
		List<Consultation> referredToMeList = getRefferredToMe(doctorId);
		ReferralWrapper wrapper;
		for(Consultation consultation : referredByMeList) {
			wrapper = new ReferralWrapper();
			//added doctors to whom 'I'referred
			wrapper.setDoctorId(consultation.getRefferedTo().getId());
			wrapper.setDoctorName(consultation.getRefferedTo().getName());
			wrapper.setSpecialization(consultation.getRefferedTo().getSpecialization());
			wrapper.setHospitalId(consultation.getRefferedTo().getHospital().getId());
			wrapper.setHospitalName(consultation.getRefferedTo().getHospital().getName());
			wrapper.setProfileImgUrl(consultation.getRefferedTo().getProfileImageUrl());
			wrapper.setPatienId(consultation.getPatient().getId());
			consultationWrapper.getReferedByMe().add(wrapper);
		}
		
		for(Consultation consultation : referredToMeList) {
			wrapper = new ReferralWrapper();
			//added doctors by whom 'I have been referred'
			wrapper.setDoctorId(consultation.getRefferedBy().getId());
			wrapper.setDoctorName(consultation.getRefferedBy().getName());
			wrapper.setSpecialization(consultation.getRefferedBy().getSpecialization());
			wrapper.setHospitalId(consultation.getRefferedBy().getHospital().getId());
			wrapper.setHospitalName(consultation.getRefferedBy().getHospital().getName());
			wrapper.setProfileImgUrl(consultation.getRefferedBy().getProfileImageUrl());
			wrapper.setPatienId(consultation.getPatient().getId());
			consultationWrapper.getRefferedToMe().add(wrapper);
		}
		return consultationWrapper;
	}

	private void createAnAppointment(Long doctorId, Long patientId) {
		appointmentService.bookAppointment(doctorId, patientId);
	}
}
