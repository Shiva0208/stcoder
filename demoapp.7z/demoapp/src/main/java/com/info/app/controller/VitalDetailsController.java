package com.info.app.controller;

import java.util.Calendar;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.VitalDetails;
import com.info.app.service.TreatmentService;
import com.info.app.service.VitalDetailsService;

@RestController
public class VitalDetailsController {

	
	@Autowired
	private VitalDetailsService vitalDetailsService;
	
	@Autowired
	private TreatmentService treatmentService;
	
    @GetMapping("/vitaldetails/{treatmentId}")
    public RestResponse getVitalDetailsByTreatment(@PathVariable Long treatmentId) throws ApiException {
        if(!treatmentService.findById(treatmentId).isPresent()) {
            throw new ApiException("Treatment not found!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    	return new RestResponse(vitalDetailsService.getByTreatment(treatmentId),HttpStatus.OK);
    }
    
    @PostMapping("/vitaldetails/{treatmentId}")
    public RestResponse addVitalDetails(@PathVariable Long treatmentId,
                            @Valid @RequestBody VitalDetails vitalDetails) throws ApiException {
         return treatmentService.findById(treatmentId)
	         .map(treatment -> {
	        	 vitalDetails.setTreatment(treatment);
	        	 return new RestResponse(vitalDetailsService.addVitalDetails(vitalDetails),HttpStatus.OK);
	         }).orElseThrow(() -> new ApiException("Treatment not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @PutMapping("/vitaldetails/{vitalDetailsId}")
    public RestResponse updateVitalDetails(@PathVariable Long vitalDetailsId,
    								@Valid @RequestBody VitalDetails updatedVitalDetails) throws ApiException {
        return vitalDetailsService.findById(vitalDetailsId)
                .map(vitalDetails -> {
                	vitalDetails.setVital(updatedVitalDetails.getVital());
                	vitalDetails.setDateTime(Calendar.getInstance());
                	vitalDetails.setReading(updatedVitalDetails.getReading());
                	vitalDetails.setRange(updatedVitalDetails.getRange());
                    return new RestResponse(vitalDetailsService.addVitalDetails(vitalDetails),HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("VitalDetails not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @DeleteMapping("/vitaldetails/{vitalDetailsId}")
    public RestResponse deleteVitalDetails(@PathVariable Long vitalDetailsId) throws ApiException {
        return vitalDetailsService.findById(vitalDetailsId)
                .map(vitalDetails -> {
                	vitalDetailsService.deleteVitalDetails(vitalDetails);
                    return new RestResponse("Deleted Successfully!",HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("VitalDetails not found!",HttpStatus.INTERNAL_SERVER_ERROR));
    }

}
