package com.info.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.app.model.VitalDetails;
import com.info.app.repository.VitalDetailsRepository;

@Service
public class VitalDetailsService {
	
	@Autowired
	private VitalDetailsRepository repository;

	public Optional<VitalDetails> findById(Long id){
		return repository.findById(id);
	}
	
	public VitalDetails addVitalDetails(VitalDetails vitalDetails) {
		return repository.save(vitalDetails);
	}

	public void deleteVitalDetails(VitalDetails vitalDetails) {
		repository.delete(vitalDetails);
	}

	public List<VitalDetails> getByTreatment(Long treatmentId) {
		return repository.findByTreatmentId(treatmentId);
	}

}
