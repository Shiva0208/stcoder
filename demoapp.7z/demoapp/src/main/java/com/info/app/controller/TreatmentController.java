package com.info.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.Treatment;
import com.info.app.service.TreatmentService;

@RestController
public class TreatmentController {
	
	@Autowired
	private TreatmentService treatmentService;

	@GetMapping("/treatment/{appointmentId}")
	public RestResponse getTreatments(@PathVariable Long appointmentId) {
		return new RestResponse(treatmentService.getTreatmentByAppointment(appointmentId),HttpStatus.OK);
	}
	
	@GetMapping("/treatment/{doctorId}/{patientId}")
	public RestResponse getTreatments(@PathVariable Long doctorId, @PathVariable Long patientId,@RequestParam Integer page, @RequestParam Integer size) {
		List<Treatment> list = treatmentService.getAllTreatmentsByDoctorAndPatient(doctorId,patientId,page,size);
		return new RestResponse(list, HttpStatus.OK);
	}
	
	@PostMapping("/treatment/{appointmentId}")
	public RestResponse addTreatment(@RequestBody Treatment treatment, @PathVariable Long appointmentId) throws ApiException {
		return new RestResponse(treatmentService.addTreatment(treatment, appointmentId),HttpStatus.OK);
	}
	
	@PutMapping("/treatment/{id}")
	public RestResponse editTreatment(@RequestBody Treatment updatedTreatment, @PathVariable Long id) throws ApiException {
		return new RestResponse(treatmentService.updateTreatment(updatedTreatment, id),HttpStatus.OK);
	}
	
	@DeleteMapping("/treatment/{id}")
	public RestResponse deleteTreatment(@PathVariable Long id) throws ApiException {
		treatmentService.deleteTreatment(id);
		return new RestResponse("DELETED", HttpStatus.OK);
	}
}
