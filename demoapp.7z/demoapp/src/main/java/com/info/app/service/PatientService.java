package com.info.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.app.model.Patient;
import com.info.app.repository.PatientRepository;

@Service
public class PatientService {
	
	@Autowired
	private PatientRepository patientRepository;
	
	public List<Patient> getAllWardPatients(Long wardId) {
		return patientRepository.getWardPatients(wardId);
	}
	
	public Patient getPatientById(Long pId) {
		return patientRepository.findById(pId).get();
	}
	
	public Patient savePatient(Patient patient) {
		return patientRepository.save(patient);
	}

	public Optional<Patient> findById(Long patientId) {
		return patientRepository.findById(patientId);
	}
	
	public List<Patient> consultantPatientList(Long referredById,Long referredToId) {
		return patientRepository.getReferralPatients(referredById, referredToId);
	}
	
	public List<Patient> searchPatient(Long hospId,String phoneNumber) {
		return patientRepository.searchPatient(hospId, phoneNumber);
	}
	
}
