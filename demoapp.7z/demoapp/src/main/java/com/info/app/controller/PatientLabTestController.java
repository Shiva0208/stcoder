package com.info.app.controller;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.PatientLabTest;
import com.info.app.service.LabDataService;
import com.info.app.service.PatientLabTestService;
import com.info.app.service.PatientService;
import com.info.app.service.TreatmentService;
import com.info.app.service.UserService;

@RestController
public class PatientLabTestController {
	
	@Autowired
	private PatientLabTestService patientLabTestService;
	
	@Autowired
	private LabDataService labDataService;
	
	@Autowired
	private TreatmentService treatmentService;
	
	@Autowired
	private PatientService patientService;
	
	@Autowired
	private UserService userService;
	
    @GetMapping("/patientlabtests/{treatmentId}")
    public RestResponse getDiagnosisByTreatment(@PathVariable Long treatmentId) throws ApiException {
        if(!treatmentService.findById(treatmentId).isPresent()) {
            throw new ApiException("Treatment not found!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    	return new RestResponse(patientLabTestService.getByTreatment(treatmentId),HttpStatus.OK);
    }
    
    @PostMapping("/patientlabtests/{treatmentId}/{patientId}/{doctorId}/{labTestId}")
    public RestResponse addPatientLabTest(@PathVariable Long treatmentId,
    						@PathVariable Long patientId,
    						@PathVariable Long doctorId,
    						@PathVariable Long labTestId,
                            @Valid @RequestBody PatientLabTest patientLabTest) throws ApiException {
    	
    	if(!labDataService.findById(labTestId).isPresent()) {
            throw new ApiException("LabTest not found!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    	
    	if(!patientService.findById(patientId).isPresent()) {
            throw new ApiException("Patient not found!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    	
    	if(!userService.findById(doctorId).isPresent()) {
            throw new ApiException("Doctor not found!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
         return treatmentService.findById(treatmentId)
	         .map(treatment -> {
	        	 patientLabTest.setTreatment(treatment);
	        	 patientLabTest.setTest(labDataService.findById(labTestId).get());
	        	 patientLabTest.setLabDcotor(userService.findById(doctorId).get());
	        	 patientLabTest.setPatient(patientService.findById(patientId).get());
	        	 return new RestResponse(patientLabTestService.addPatientLabTest(patientLabTest),HttpStatus.OK);
	         }).orElseThrow(() -> new ApiException("Treatment not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @PutMapping("/patientlabtests/{patientLabTestId}")
    public RestResponse updatePatientLabTest(@PathVariable Long patientLabTestId,
    								@Valid @RequestBody PatientLabTest updatedPatientLabTest) throws ApiException {
        return patientLabTestService.findById(patientLabTestId)
                .map(patientLabTest -> {
                	patientLabTest.setTestResult(updatedPatientLabTest.getTestResult());
                	patientLabTest.setModifiedOn(new Date());
                    return new RestResponse(patientLabTestService.addPatientLabTest(patientLabTest),HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("PatientLabTest not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @DeleteMapping("/patientlabtests/{patientLabTestId}")
    public RestResponse deletePatientLabTest(@PathVariable Long patientLabTestId) throws ApiException {
        return patientLabTestService.findById(patientLabTestId)
                .map(patientLabTest -> {
                	patientLabTestService.deletePatientLabTest(patientLabTest);
                    return new RestResponse("Deleted Successfully!",HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("PatientLabTest not found!",HttpStatus.INTERNAL_SERVER_ERROR));
    }

}
