package com.info.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.info.app.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
	@Query(value = "select u.* from user u, hospital h where h.hospital_login_id = :hospitalLoginId and u.hospital_id = h.id", nativeQuery = true)
	List<User> getHospitalUsers(@Param("hospitalLoginId") String hospitalLoginId);
	
	@Query(value = "select u.* from user u where u.hospital_id = :hospitalId and u.role = 'DOCTOR'", nativeQuery = true)
	List<User> getAllHospitalUsers(@Param("hospitalId") Long hospitalId);
	
	@Query(value = "select u.* from user u where u.user_name = :userName and u.pass = :password", nativeQuery = true)
	List<User> loadUserByUsernameAndPassword(@Param("userName") String userName, @Param("password") String password);
	
	@Query(value = "select u.* from user u where u.user_name = :userName", nativeQuery = true)
	List<User> loadUserByUsername(@Param("userName") String userName);
}
