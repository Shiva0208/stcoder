package com.info.app.model;

public enum AppointmentStatus {
	NEW("NEW"),
	COMPLETED("COMPLETED");
	
	private String label;
	private AppointmentStatus(String label) {
		this.label = label;
	}
	public String getLabel() {
		return label;
	}
}
