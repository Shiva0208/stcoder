package com.info.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "billing")
public class Billing {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;

	@OneToMany(mappedBy = "billing",fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
	private List<BillingItem> billingItems = new ArrayList<>();
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "treatment_id", referencedColumnName = "id")
	private Treatment treatment;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<BillingItem> getBillingItems() {
		return billingItems;
	}

	public void setBillingItems(List<BillingItem> billingItems) {
		this.billingItems = billingItems;
	}

	public Treatment getTreatment() {
		return treatment;
	}

	public void setTreatment(Treatment treatment) {
		this.treatment = treatment;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Billing billing = (Billing) o;
		return Objects.equals(id, billing.id) &&
				Objects.equals(billingItems, billing.billingItems);
	}

	@Override
	public int hashCode() {
		return Objects.hash(billingItems);
	}
}
