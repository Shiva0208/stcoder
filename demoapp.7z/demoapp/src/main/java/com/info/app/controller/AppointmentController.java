package com.info.app.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.Appointment;
import com.info.app.response.wrapper.AppointmentWrapper;
import com.info.app.service.AppointmentService;
import com.info.app.service.UserService;

@RestController
@RequestMapping("appointments")
public class AppointmentController {
	
	@Autowired
	private AppointmentService appointmentService;
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/doctorAppointments/{doctorId}", method = RequestMethod.GET)
	public RestResponse getDoctorAppointments(@PathVariable Long doctorId, Pageable pageable) throws ApiException {
		if(verifyDoctor(doctorId)) {
			Map<String, List<AppointmentWrapper>> appointments = appointmentService.getAllAppointments(doctorId);
			return new RestResponse(appointments,HttpStatus.OK,"SUCCESS");
		} else {
			throw new ApiException("Doctor is not registered with this hospital..", HttpStatus.NO_CONTENT);
		}
	}
	
	@RequestMapping(value="/todaysAppointments/{doctorId}", method = RequestMethod.GET)
	public RestResponse getDoctorAppointmentsForToday(@PathVariable Long doctorId) throws ApiException {
		if(verifyDoctor(doctorId)) {
			List<AppointmentWrapper> appointments = appointmentService.getAppointmentsForToday(doctorId, new Date());
			return new RestResponse(appointments,HttpStatus.OK,"SUCCESS");
		} else {
			throw new ApiException("Doctor is not registered with this hospital..", HttpStatus.NO_CONTENT);
		}
	}
	
	@RequestMapping(value="/todaysAllAppointments", method = RequestMethod.GET)
	public RestResponse getDoctorAppointmentsForToday() throws ApiException {
		List<AppointmentWrapper> appointments = appointmentService.getAllAppointmentsForToday(new Date());
		return new RestResponse(appointments,HttpStatus.OK,"SUCCESS");
	}
	
	@RequestMapping(value="/patientAppointments/{patientId}", method = RequestMethod.GET)
	public RestResponse getPatientAppointments(@PathVariable Long patientId, Pageable pageable) {
		Page<Appointment> appointments = appointmentService.getPatientAppointments(pageable, patientId);
		return new RestResponse(appointments,HttpStatus.OK,"SUCCESS");
	}
	
	@RequestMapping(value = "/appointment/{doctorId}/{patientId}", method = RequestMethod.GET)
	public RestResponse getAllAppointments(@PathVariable Long doctorId, @PathVariable Long patientId,Pageable pageable) {
		Map<String, List<AppointmentWrapper>> appointments = appointmentService.getAllAppointments(doctorId);
		return new RestResponse(appointments, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/appointment/{doctorId}/{patientId}", method = RequestMethod.POST)
	public RestResponse bookAppointment(@PathVariable Long doctorId, @PathVariable Long patientId) {
		return new RestResponse(appointmentService.bookAppointment(doctorId, patientId), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/appointment/{doctorId}", method = RequestMethod.POST)
	public RestResponse bookAppointmentWithPatient(@RequestBody Appointment appointment, @PathVariable Long doctorId) {
		return new RestResponse(appointmentService.bookPatientAppointment(appointment, doctorId), HttpStatus.OK);
	}
	
	private boolean verifyDoctor(Long doctorId) {
		return userService.getUser(doctorId) != null ? true : false;
	}
	
	@RequestMapping(value="/all/{doctorId}", method = RequestMethod.GET)
	public RestResponse getAllAptsDates(@PathVariable Long doctorId) throws ApiException{
		return new RestResponse(appointmentService.getDatewiseAppointments(doctorId),HttpStatus.OK);
	}
}
