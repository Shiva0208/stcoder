package com.info.app.common;

import org.springframework.http.HttpStatus;

public class RestResponse {
	
	private MetaData metaData;
	
	private Object data;
	
	public RestResponse() {
		this.metaData = new MetaData();
	}

	public RestResponse(Object data,HttpStatus  statusCode) {
		this.data = data;
		this.metaData = new MetaData(statusCode);
	}
	
	public RestResponse(Object data,HttpStatus statusCode, String message) {
		this.data = data;
		this.metaData = new MetaData(statusCode,message);
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public MetaData getMetaData() {
		return metaData;
	}

	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}
	
}
