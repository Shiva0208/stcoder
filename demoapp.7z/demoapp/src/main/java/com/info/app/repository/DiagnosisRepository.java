package com.info.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.info.app.model.Diagnosis;

@Repository
public interface DiagnosisRepository extends JpaRepository<Diagnosis, Long> {
	List<Diagnosis> findByTreatmentId(Long treatmentId);

	@Query(value = "select d.* from diagnosis d left join treatment t on d.treatment_id = t.id where t.appointment_id = :appointmentId", nativeQuery = true)
	List<Diagnosis> getByAppointmentId(Long appointmentId);
}
