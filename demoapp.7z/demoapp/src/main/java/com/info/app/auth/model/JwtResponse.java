package com.info.app.auth.model;

import java.io.Serializable;

import com.info.app.response.wrapper.UserWrapper;

public class JwtResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private final String jwttoken;
	
	private UserWrapper user;

	public JwtResponse(String jwttoken) {
		this.jwttoken = jwttoken;
	}

	public String getToken() {
		return this.jwttoken;
	}

	public UserWrapper getUser() {
		return user;
	}

	public void setUser(UserWrapper user) {
		this.user = user;
	}
	
}
