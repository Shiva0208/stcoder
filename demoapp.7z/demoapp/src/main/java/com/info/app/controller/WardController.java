package com.info.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.service.WardService;

@RestController
@RequestMapping(value = "/wards")
public class WardController {
	
	@Autowired
	private WardService wardService;
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public RestResponse getAllWards() {
		return new RestResponse(wardService.getAllWards(),HttpStatus.OK);
	}
	
	@RequestMapping(value = "/patients/{wardId}", method = RequestMethod.GET)
	public RestResponse getWardPatients(@PathVariable Long wardId) {
		return new RestResponse(wardService.getWardPatients(wardId),HttpStatus.OK);
	}
	
}
