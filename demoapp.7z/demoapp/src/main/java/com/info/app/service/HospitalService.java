package com.info.app.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.info.app.exceptions.ApiException;
import com.info.app.model.Hospital;
import com.info.app.model.HospitalDirector;
import com.info.app.model.User;
import com.info.app.repository.HospitalDirectorRepository;
import com.info.app.repository.HospitalRepository;
import com.info.app.repository.UserRepository;
import com.info.app.response.wrapper.UserWrapper;

@Service
public class HospitalService {
	
	@Autowired
	private HospitalDirectorRepository hospitalDirectorRepository;
	
	@Autowired
	private HospitalRepository hospitalRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	public List<Hospital> getAllHospitals(){
		List<Hospital> hospitals = new ArrayList<>();
		
		for (Hospital hospital : hospitalRepository.findAll()) {
			hospitals.add(hospital);
		}
		return hospitals;
	}
	
	public Hospital getHospitalById(Long id) {
		return hospitalRepository.findById(id).get();
	}
	public Hospital getHospitalByLoginId(String hospitalLoginId) {
		return hospitalRepository.findByHospitalLoginId(hospitalLoginId);
	}

	public List<UserWrapper> getHospitalUsers(String hospitalLoginId) {
		List<User> hospitalUsers = userRepository.getHospitalUsers(hospitalLoginId);
		return hospitalUsers.stream().map(hu -> new UserWrapper(hu)).collect(Collectors.toList());
	}
	
	public Hospital registerHospital(JSONObject hospitalDetailsJson) throws ApiException {
		try {
			JSONObject directorDetails = (JSONObject) hospitalDetailsJson.get("directorDetails");
			JSONObject hospitalInfo = (JSONObject) hospitalDetailsJson.get("hospitalDetails");
			ObjectMapper mapper = new ObjectMapper();
			HospitalDirector director = mapper.readValue(directorDetails.toString(), HospitalDirector.class);
			director.setCreatedOn(new Date());
			director.setModifiedOn(new Date());
			Hospital hospital = mapper.readValue(hospitalInfo.toString(), Hospital.class);
			director = hospitalDirectorRepository.save(director);
			hospital.setDirectorId(director.getId());
			hospital.setCreatedOn(new Date());
			hospital.setModifiedOn(new Date());
			return hospitalRepository.save(hospital);
		} catch(JSONException|JsonProcessingException je) {
			throw new ApiException("Error in json parsing "+hospitalDetailsJson + " "+je.getMessage(), HttpStatus.BAD_REQUEST);
		} 
	}

}
