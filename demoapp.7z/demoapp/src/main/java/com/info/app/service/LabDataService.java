package com.info.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.app.model.LabTest;
import com.info.app.repository.LabDataRepository;

@Service
public class LabDataService {
	@Autowired
	private LabDataRepository labDataRepository;
	
	public List<LabTest> getLabData() {
		return labDataRepository.findAll();
	}

	public LabTest addLabData(LabTest labTest) {
		return labDataRepository.save(labTest);
	}

	public LabTest editLabData(LabTest labTest) {
		return labDataRepository.save(labTest);
	}

	public void deleteLabData(LabTest labTest) {
		labDataRepository.delete(labTest);
	}

	public List<LabTest> addAllLabData(List<LabTest> labTests) {
		return labDataRepository.saveAll(labTests);
	}

	public Optional<LabTest> findById(Long labTestId) {
		return labDataRepository.findById(labTestId);
	}
}
