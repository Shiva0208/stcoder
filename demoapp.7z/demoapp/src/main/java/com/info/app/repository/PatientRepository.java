package com.info.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.info.app.model.Patient;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {
	
	@Query(value = "select p.* from patient p where p.ward_id = :wardId and p.discharge_date is null and p.patient_type = 'IPD'", nativeQuery = true)
	public List<Patient> getWardPatients(Long wardId);

	@Query(value = "select p.* from patient p left join consultation c on p.id = c.patient_id where c.reffered_by_id = :referredById and c.reffered_to_id = :referredToId", nativeQuery = true)
	public List<Patient> getReferralPatients(Long referredById, Long referredToId);

	@Query(value = "select p.* from patient p left join user u on p.doctor_id = u.id where p.phone_number like %:phoneNumber% and u.hospital_id = :hospId", nativeQuery = true)
	public List<Patient> searchPatient(Long hospId, String phoneNumber);

	
}
