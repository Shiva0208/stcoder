package com.info.app.exceptions;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.info.app.common.ErrorResponse;

@ControllerAdvice
public class CustomExceptionHandler {
	
	@ExceptionHandler(ApiException.class)
	public @ResponseBody ErrorResponse throwException(ApiException apiException, final HttpServletResponse response) {
		response.setStatus(apiException.getHttpStatus().value());
		return new ErrorResponse(apiException);
	}
	
}
