package com.info.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.BillingItem;
import com.info.app.service.BillingItemService;
import com.info.app.service.BillingService;

@RestController
public class BillingItemController {
	
	@Autowired
	private BillingItemService billingItemService;
	
	@Autowired 
	private BillingService billingService;
	
	@GetMapping("/billingitems/{billingId}")
    public RestResponse getBillingItemsByBillingId(@PathVariable Long billingId) throws ApiException {
        if(!billingService.findById(billingId).isPresent()) {
            throw new ApiException("Billing not found!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    	return new RestResponse(billingItemService.getByBillingId(billingId),HttpStatus.OK);
    }
    
    @PostMapping("/billingitems/{billingId}")
    public RestResponse addBillingItem(@PathVariable Long billingId,
                            @Valid @RequestBody BillingItem billingItem) throws ApiException {
         return billingService.findById(billingId)
	         .map(billing -> {
	        	 billingItem.setBilling(billing);
	        	 return new RestResponse(billingItemService.addBillingItem(billingItem),HttpStatus.OK);
	         }).orElseThrow(() -> new ApiException("Billing not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @PutMapping("/billingitems/{billingItemId}")
    public RestResponse updateBillingItem(@PathVariable Long billingItemId,
    								@Valid @RequestBody BillingItem updatedBillingItem) throws ApiException {
        return billingItemService.findById(billingItemId)
                .map(billingItem -> {
                	billingItem.setItemName(updatedBillingItem.getItemName());
                	billingItem.setPrice(updatedBillingItem.getPrice());
                    return new RestResponse(billingItemService.addBillingItem(billingItem),HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("BillingItem not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @DeleteMapping("/billingitems/{billingItemId}")
    public RestResponse deleteBillingItem(@PathVariable Long billingItemId) throws ApiException {
        return billingItemService.findById(billingItemId)
                .map(billingItem -> {
                	billingItemService.deleteBillingItem(billingItem);
                    return new RestResponse("Deleted Successfully!",HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("BillingItem not found!",HttpStatus.INTERNAL_SERVER_ERROR));
    }


}
