package com.info.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.app.model.Billing;
import com.info.app.repository.BillingRepository;

@Service
public class BillingService {
	@Autowired
	private BillingRepository repository;

	public Optional<Billing> findById(Long id){
		return repository.findById(id);
	}
	
	public Billing addBilling(Billing billing) {
		return repository.save(billing);
	}

	public void deleteBilling(Billing billing) {
		repository.delete(billing);
	}

	public List<Billing> getByTreatment(Long treatmentId) {
		return repository.findByTreatmentId(treatmentId);
	}

}
