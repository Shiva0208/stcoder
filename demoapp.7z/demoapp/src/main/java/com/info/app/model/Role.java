package com.info.app.model;

public enum Role {
	ADMIN,
	DOCTOR,
	CHEMIST,
	PATHOLOGIST
}
