package com.info.app.model;

public enum PatientType {
	IPD("IPD"),
	OPD("OPD");
	
	private String label;
	PatientType(String label) {
		this.label = label;
	}
	public String getLabel() {
		return label;
	}
}

