package com.info.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.info.app.model.LabTest;

public interface LabTestRepository extends JpaRepository<LabTest, Long>{

}
