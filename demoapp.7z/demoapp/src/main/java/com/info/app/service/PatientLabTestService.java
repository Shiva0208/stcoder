package com.info.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.app.model.LabTest;
import com.info.app.model.PatientLabTest;
import com.info.app.repository.LabTestRepository;
import com.info.app.repository.PatientLabTestRepository;

@Service
public class PatientLabTestService {
	
	@Autowired
	private PatientLabTestRepository repository;
	
	@Autowired
	private LabTestRepository labTestRepository;

	public Optional<PatientLabTest> findById(Long id){
		return repository.findById(id);
	}
	
	public PatientLabTest addPatientLabTest(PatientLabTest patientLabTest) {
		return repository.save(patientLabTest);
	}

	public void deletePatientLabTest(PatientLabTest patientLabTest) {
		repository.delete(patientLabTest);
	}

	public List<PatientLabTest> getByTreatment(Long treatmentId) {
		return repository.findByTreatmentId(treatmentId);
	}

}
