package com.info.app.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "treatment")
public class Treatment implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2601529091458913970L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
	
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "appointment_id", referencedColumnName = "id")
	private Appointment appointment;
	
	@OneToMany(mappedBy = "treatment",cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private Set<Diagnosis> diagnosis;
	
	@OneToOne(mappedBy = "treatment", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private Prescription prescription;
	
	@OneToMany(mappedBy = "treatment", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private Set<PatientLabTest> patientLabTests;
	
	@OneToMany(mappedBy = "treatment", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private Set<VitalDetails> vitalDetails;
	
	@OneToOne(mappedBy = "treatment", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
	private Billing billing;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Appointment getAppointment() {
		return appointment;
	}
	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}
	public Set<Diagnosis> getDiagnosis() {
		return diagnosis;
	}
	public void setDiagnosis(Set<Diagnosis> diagnosis) {
		this.diagnosis = diagnosis;
	}
	public Prescription getPrescription() {
		return prescription;
	}
	public void setPrescription(Prescription prescription) {
		this.prescription = prescription;
	}
	public Set<PatientLabTest> getPatientLabTests() {
		return patientLabTests;
	}
	public void setPatientLabTests(Set<PatientLabTest> patientLabTests) {
		this.patientLabTests = patientLabTests;
	}
	public Set<VitalDetails> getVitalDetails() {
		return vitalDetails;
	}
	public void setVitalDetails(Set<VitalDetails> vitalDetails) {
		this.vitalDetails = vitalDetails;
	}
	public Billing getBilling() {
		return billing;
	}
	public void setBilling(Billing billing) {
		this.billing = billing;
	}
	
}
