package com.info.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.Medication;
import com.info.app.service.MedicationService;
import com.info.app.service.PrescriptionService;
import com.info.app.service.TreatmentService;

@RestController
public class MedicationController {
	
	@Autowired
	private MedicationService medicationService;
	
	@Autowired
	private TreatmentService treatmentService;
	
	@Autowired
	private PrescriptionService prescriptionService;
	
    @GetMapping("/medications/{treatmentId}")
    public RestResponse getDiagnosisByTreatment(@PathVariable Long treatmentId) throws ApiException {
        if(!treatmentService.findById(treatmentId).isPresent()) {
            throw new ApiException("Treatment not found!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    	return new RestResponse(medicationService.getByTreatment(treatmentId),HttpStatus.OK);
    }
    
    @PostMapping("/medications/{prescriptionId}")
    public RestResponse addDiagnosis(@PathVariable Long prescriptionId,
                            @Valid @RequestBody Medication medication) throws ApiException {
    	return prescriptionService.findById(prescriptionId)
        .map(prescription -> {
			 medication.setPrescription(prescription);
		 	 return new RestResponse(medicationService.addMedication(medication),HttpStatus.OK);
        }).orElseThrow(() -> new ApiException("Prescription not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @PutMapping("/medications/{medicationId}")
    public RestResponse updateDiagnosis(@PathVariable Long medicationId,
    								@Valid @RequestBody Medication updatedMedication) throws ApiException {
        return medicationService.findById(medicationId)
                .map(medication -> {
                	medication.setMedicineName(updatedMedication.getMedicineName());
                	medication.setAfterMeal(updatedMedication.isAfterMeal());
                	medication.setBeforeMeal(updatedMedication.isBeforeMeal());
                	medication.setMorning(updatedMedication.isMorning());
                	medication.setAfterNoon(updatedMedication.isAfterNoon());
                	medication.setNight(updatedMedication.isNight());
                	medication.setDays(updatedMedication.getDays());
                	return new RestResponse(medicationService.addMedication(medication),HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("Medication not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @DeleteMapping("/medications/{medicationId}")
    public RestResponse deleteMedication(@PathVariable Long medicationId) throws ApiException {
        return medicationService.findById(medicationId)
                .map(medication -> {
                    medicationService.deleteMedication(medication);
                    return new RestResponse("Deleted Successfully!",HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("Medication not found!",HttpStatus.INTERNAL_SERVER_ERROR));
    }

}
