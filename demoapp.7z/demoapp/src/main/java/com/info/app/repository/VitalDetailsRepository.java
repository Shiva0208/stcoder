package com.info.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.info.app.model.VitalDetails;

public interface VitalDetailsRepository extends JpaRepository<VitalDetails, Long> {

	List<VitalDetails> findByTreatmentId(Long treatmentId);

}
