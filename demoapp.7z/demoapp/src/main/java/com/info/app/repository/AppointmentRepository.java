package com.info.app.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.info.app.model.Appointment;
import com.info.app.model.User;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
	
	Page<Appointment> findByUser(Pageable pageable, User user);
	
	Page<Appointment> findByPatient(Pageable pageable, Long patientId);
	
	List<Appointment> findByUserAndPatient(Long userId, Long patientId	);

	@Query(value = "select a.* from appointment a where a.user_id = :userId "
			+ "and DATE(a.appointment_date) = DATE(:date) and a.appointment_status = 'NEW'", nativeQuery = true)
	List<Appointment> getTodaysAppointments(Long userId, Date date);
	
	@Query(value = "select a.* from appointment a where"
			+ " DATE(a.appointment_date) = DATE(:date) order by a.appointment_date desc", nativeQuery = true)
	List<Appointment> getTodaysAllAppointments(Date date);

	@Query(value = "select a.* from appointment a where a.user_id = :userId "
			+ "and DATE(a.appointment_date) > DATE(:date) and a.appointment_status = 'NEW'", nativeQuery = true)
	List<Appointment> getFutureAppointments(Long userId, Date date);
	
	@Query(value = "select a.* from appointment a where a.user_id = :userId "
			+ "and DATE(a.appointment_date) = DATE(:date) and a.appointment_status = 'COMPLETED'", nativeQuery = true)
	List<Appointment> getRecentAppointments(Long userId, Date date);
	
	@Query(value = "select a.* from appointment a where a.user_id = :userId "
			+ "and DATE(a.appointment_date) < DATE(:date) and a.appointment_status = 'COMPLETED'", nativeQuery = true)
	List<Appointment> getPastAppointments(Long userId, Date date);
	
	@Query(value = "select a.* from appointment a where a.user_id = :doctorId and "
			+ "a.appointment_status = 'COMPLETED'", nativeQuery = true)
	List<Appointment> getDateWiseAppointments(Long doctorId);
}
