package com.info.app.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.info.app.model.Appointment;
import com.info.app.model.Treatment;
import com.info.app.service.TreatmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.response.wrapper.PatientWrapper;
import com.info.app.service.PatientService;
import com.info.app.service.WardService;

@RestController
public class PatientController {
	
	@Autowired
	private PatientService patientService;
	
	@Autowired
	private WardService wardService;
	
	@Autowired
	private TreatmentService treatmentService;
	
	@GetMapping(value = "/patients")
	public RestResponse getPatientList(@RequestParam("wardId") Optional<Long> optionalWardId,
			@RequestParam("referredBy") Optional<Long> referredById,
			@RequestParam("referredTo") Optional<Long> referredToId) throws ApiException {
	    
		if(optionalWardId.isPresent() && (referredById.isPresent() || referredToId.isPresent())) {
	    	throw new ApiException("Only one type of request should be sent at a time", HttpStatus.BAD_REQUEST);
	    } 
	    
		List<PatientWrapper> patientList = new ArrayList<PatientWrapper>();
		
		optionalWardId.ifPresent(wardId->{
			patientList.addAll(wardService.getWardPatients(wardId).stream().map(patient -> setAppointmentAndTreatment(new PatientWrapper(patient)))
					.collect(Collectors.toList()));
		});
		
		referredById.ifPresent(rbId->referredToId.ifPresent(rtId->{
			patientList.clear();
			patientList.addAll(patientService.consultantPatientList(referredById.get(), referredToId.get()).stream()
					.map(patient -> setAppointmentAndTreatment(new PatientWrapper(patient))).collect(Collectors.toList()));
		}));
		
		return new RestResponse(patientList, HttpStatus.OK);
	}
	
	@GetMapping(value="/patients/search/{hospId}/{phoneNumber}")
	public RestResponse searchPatient(@PathVariable Long hospId, @PathVariable String phoneNumber)throws ApiException {
		return new RestResponse(patientService.searchPatient(hospId, phoneNumber),HttpStatus.OK);
	}

	private PatientWrapper setAppointmentAndTreatment(PatientWrapper wrapper) {
		Optional.of(wrapper.getPatientId()).ifPresent(id->{
			Treatment t = treatmentService.getTreatmentForPatient(id);
			Appointment a = t.getAppointment();
			wrapper.setTreatmentId(t.getId());
			wrapper.setAppointmentId(a.getId());
		});
		return wrapper;
	}
}
