package com.info.app.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.info.app.exceptions.ApiException;
import com.info.app.model.User;
import com.info.app.repository.UserRepository;
import com.info.app.response.wrapper.UserWrapper;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private HospitalService hospitalService;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	public List<User> getAllUsers(){
		List<User> users = new ArrayList<>();
		for(User user: userRepository.findAll()) {
			users.add(user);
		}
		return users;
	}
	
	public User getUser(Long userId) {
		return userRepository.findById(userId).get();
	}
	
	public User loadUser(String userName, String password) {
		return userRepository.loadUserByUsernameAndPassword(userName, password).get(0);
	}
	
	public User loadUserByUsername(String userName) {
		return userRepository.loadUserByUsername(userName).get(0);
	}
	
	public void saveReferralsForDoctor(Long userId, List<Long> referralIds) {
		User referrent = userRepository.findById(userId).get();
		User referral = null;
		for(Long referralId : referralIds) {
			referral = userRepository.findById(referralId).get();
			referral.setReferent(referrent);
			referral.setModifiedOn(new Date());
			userRepository.save(referral);
			referral = null;
		}
	}

	public User registerDoctor(User newUser, Long hospitalId) throws ApiException {
			newUser.setCreatedOn(new Date());
			newUser.setModifiedOn(new Date());
			newUser.setHospital(hospitalService.getHospitalById(hospitalId));
			newUser.setPassword(passwordEncoder.encode(newUser.getPassword()));
			
			newUser = userRepository.save(newUser);
			newUser.setPassword(null);
			return newUser;
	}

	public Optional<User> findById(Long doctorId) {
		return userRepository.findById(doctorId);
	}
	
	public List<UserWrapper> getAllHospitalUsers(Long hospitalId) {
		return userRepository.getAllHospitalUsers(hospitalId).stream().map(user -> new UserWrapper(user))
				.collect(Collectors.toList());
	}
	
}
