package com.info.app.response.wrapper;

public class ReferralWrapper {
	
	private Long doctorId;
	private String doctorName;
	private Long hospitalId;
	private String hospitalName;
	private Long patienId;
	private String specialization;
	private String profileImgUrl;
	
	public Long getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Long doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public Long getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(Long hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getSpecialization() {
		return specialization;
	}
	
	public Long getPatienId() {
		return patienId;
	}
	public void setPatienId(Long patienId) {
		this.patienId = patienId;
	}
	
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getProfileImgUrl() {
		return profileImgUrl;
	}
	public void setProfileImgUrl(String profileImgUrl) {
		this.profileImgUrl = profileImgUrl;
	}
	
	

}
