package com.info.app.common;

import org.springframework.http.HttpStatus;

public class MetaData {
	
	private HttpStatus responseStatus;
	
	private String message;
	
	private Integer responseStatusCode;
	
	public MetaData() {
		this.responseStatus = null;
		this.message = "";
		this.responseStatusCode = -1;
	}
	
	public MetaData(HttpStatus status) {
		this.responseStatus = status;
		this.responseStatusCode = this.responseStatus.value();
		this.message = this.responseStatusCode == 200? "SUCCESS": "FAILED";
	}

	public MetaData(HttpStatus responseStatus, String message) {
		this.responseStatus = responseStatus;
		this.message = message;
		this.responseStatusCode = this.responseStatus.value();
	}

	public HttpStatus getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(HttpStatus responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getResponseStatusCode() {
		return responseStatusCode;
	}

	public void setResponseStatusCode(Integer responseStatusCode) {
		this.responseStatusCode = responseStatusCode;
	}
	
}
