package com.info.app.response.wrapper;

import java.util.ArrayList;
import java.util.List;

public class ConsultantWrapper {

	private List<ReferralWrapper> referedByMe = new ArrayList<>();
	private List<ReferralWrapper> refferedToMe = new ArrayList<>();
	public List<ReferralWrapper> getReferedByMe() {
		return referedByMe;
	}
	public void setReferedByMe(List<ReferralWrapper> referedByMe) {
		this.referedByMe = referedByMe;
	}
	public List<ReferralWrapper> getRefferedToMe() {
		return refferedToMe;
	}
	public void setRefferedToMe(List<ReferralWrapper> refferedToMe) {
		this.refferedToMe = refferedToMe;
	}
	
}
