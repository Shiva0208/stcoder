package com.info.app.response.wrapper;

import com.info.app.model.User;

public class UserWrapper {
	private Long userId;
	private String name;
	private String userName;
	private String email;
	private Long hospitalId;
	private String hospitalName;
	private String hospitalAddress;
	private String role;
	private String profileImageUrl;
	private String specialization;
	private String license;
	
	public UserWrapper(User user) {
		this.userId = user.getId();
		this.name = user.getName();
		this.userName = user.getUserName();
		this.email = user.getEmail();
		this.hospitalId = user.getHospital().getId();
		this.hospitalName = user.getHospital().getName();
		this.hospitalAddress = user.getHospital().getAddress();
		this.role = user.getRole().toString();
		this.profileImageUrl = user.getProfileImageUrl();
		this.specialization = user.getSpecialization();
		this.license = user.getLicense();
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(Long hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getHospitalAddress() {
		return hospitalAddress;
	}
	public void setHospitalAddress(String hospitalAddress) {
		this.hospitalAddress = hospitalAddress;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getProfileImageUrl() {
		return profileImageUrl;
	}
	public void setProfileImageUrl(String profileImageUrl) {
		this.profileImageUrl = profileImageUrl;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getLicense() {
		return license;
	}
	public void setLicense(String license) {
		this.license = license;
	}
	
}
