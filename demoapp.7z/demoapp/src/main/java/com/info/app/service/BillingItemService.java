package com.info.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.app.model.BillingItem;
import com.info.app.model.VitalDetails;
import com.info.app.repository.BillingItemRepository;
import com.info.app.repository.VitalDetailsRepository;

@Service
public class BillingItemService {
	
	@Autowired
	private BillingItemRepository repository;

	public Optional<BillingItem> findById(Long id){
		return repository.findById(id);
	}
	
	public BillingItem addBillingItem(BillingItem billingItem) {
		return repository.save(billingItem);
	}

	public void deleteBillingItem(BillingItem billingItem) {
		repository.delete(billingItem);
	}

	public List<BillingItem> getByBillingId(Long billingId) {
		return repository.findByBillingId(billingId);
	}

}
