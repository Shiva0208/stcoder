package com.info.app.controller;

import com.info.app.exceptions.ApiException;
import com.info.app.response.wrapper.PatientDetailsWrapper;
import com.info.app.service.PatientDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import com.info.app.common.RestResponse;

@RestController
public class PatientDetailsController {

	@Autowired
	private PatientDetailsService patientDetailsService;
	@PostMapping(value = "/details",consumes = "application/json")
	public RestResponse saveDetails(@RequestBody PatientDetailsWrapper patientDetailsWrapper) throws ApiException {
		return new RestResponse(patientDetailsService.saveDetails(patientDetailsWrapper), HttpStatus.OK);
	}

	@GetMapping("/details/{appointmentId}")
	public RestResponse getDetails(@PathVariable Long appointmentId) throws ApiException {
		return new RestResponse(patientDetailsService.getDetails(appointmentId),HttpStatus.OK);
	}
}
