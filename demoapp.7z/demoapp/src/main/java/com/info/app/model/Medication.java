package com.info.app.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Objects;

@Entity
@Table(name = "medication")
public class Medication {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "medicine_name")
	private String medicineName; 
	
	@JsonIgnore
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "prescription_id", referencedColumnName = "id")
	private Prescription prescription;
	
	@Column(name = "morning", nullable = false, columnDefinition = "TINYINT", length = 1)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private Boolean morning = Boolean.FALSE;
	
	@Column(name = "afternoon", nullable = false, columnDefinition = "TINYINT", length = 1)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private boolean afterNoon = Boolean.FALSE;
	
	@Column(name = "night", nullable = false, columnDefinition = "TINYINT", length = 1)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private Boolean night = Boolean.FALSE;
	
	@Column(name = "before_meal", nullable = false, columnDefinition = "TINYINT", length = 1)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private Boolean beforeMeal = Boolean.FALSE;
	
	@Column(name = "after_meal", nullable = false, columnDefinition = "TINYINT", length = 1)
	@Type(type = "org.hibernate.type.NumericBooleanType")
	private Boolean afterMeal = Boolean.FALSE;
	
	@Column(name = "days")
	private Integer days;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

//	public Medicine getMedicine() {
//		return medicine;
//	}
//
//	public void setMedicine(Medicine medicine) {
//		this.medicine = medicine;
//	}
	
	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	
	public Prescription getPrescription() {
		return prescription;
	}

	public void setPrescription(Prescription prescription) {
		this.prescription = prescription;
	}

	public Boolean isMorning() {
		return morning;
	}

	public void setMorning(Boolean morning) {
		this.morning = morning;
	}

	public boolean isAfterNoon() {
		return afterNoon;
	}

	public void setAfterNoon(boolean afterNoon) {
		this.afterNoon = afterNoon;
	}

	public Boolean isNight() {
		return night;
	}

	public void setNight(Boolean night) {
		this.night = night;
	}

	public Boolean isBeforeMeal() {
		return beforeMeal;
	}

	public void setBeforeMeal(Boolean beforeMeal) {
		this.beforeMeal = beforeMeal;
	}

	public Boolean isAfterMeal() {
		return afterMeal;
	}

	public void setAfterMeal(Boolean afterMeal) {
		this.afterMeal = afterMeal;
	}

	public Integer getDays() {
		return days;
	}

	public void setDays(Integer days) {
		this.days = days;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Medication that = (Medication) o;
		return afterNoon == that.afterNoon &&
				medicineName.equals(that.medicineName) &&
				morning.equals(that.morning) &&
				night.equals(that.night) &&
				beforeMeal.equals(that.beforeMeal) &&
				afterMeal.equals(that.afterMeal) &&
				days.equals(that.days);
	}

	@Override
	public int hashCode() {
		return Objects.hash(medicineName, morning, afterNoon, night, beforeMeal, afterMeal, days);
	}
}
