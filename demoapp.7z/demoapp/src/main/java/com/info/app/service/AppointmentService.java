package com.info.app.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.info.app.model.Appointment;
import com.info.app.model.Diagnosis;
import com.info.app.model.Patient;
import com.info.app.model.User;
import com.info.app.repository.AppointmentRepository;
import com.info.app.response.wrapper.AppointmentWrapper;
import com.info.app.response.wrapper.DateWiseAppointmentsWrapper;

@Service
public class AppointmentService {
	
	@Autowired
	private AppointmentRepository appointmentRepository;
	
	@Autowired
	private DiagnosisService diagnosisService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private PatientService patientService;
	
	public List<Appointment> getAllAppointments() {
		List<Appointment> appointments = new ArrayList<Appointment>();
		for(Appointment appointment: appointmentRepository.findAll()) {
			appointments.add(appointment);
		} 
		return appointments;
	}
	
	public Appointment getAppointmentById(Long id) {
		try {
			return appointmentRepository.findById(id).get();
		}catch (Exception e) {
			return null;
		}
	}
	
	public Page<Appointment> getDoctorAppointments(Pageable pageable, Long userId) {
		return appointmentRepository.findByUser(pageable, userService.getUser(userId));
	}
	
	public List<DateWiseAppointmentsWrapper> getDatewiseAppointments(Long doctorId) {
		return appointmentRepository.getDateWiseAppointments(doctorId).stream().filter(apt->
			apt.getTreatment()!=null).map(a->{
			DateWiseAppointmentsWrapper d = new DateWiseAppointmentsWrapper();
			d.setAppointmentId(a.getId());
			d.setAppointmentDate(a.getAppointmentDate().getTime());
			d.setTreatmentId(a.getTreatment().getId());
			d.setDiagnosis(getOne(getDignosisOfAppointment(a.getTreatment().getId())));
			return d;
		}).collect(Collectors.toList());
	}
	
	private String getOne(List<Diagnosis> dList) {
		if(dList!=null && !dList.isEmpty())
			return dList.get(0)!=null?dList.get(0).getName():"";
		else
			return "";
	}
	private List<Diagnosis> getDignosisOfAppointment(Long treatmentId){
		return diagnosisService.getByTreatment(treatmentId);
	}
	public Page<Appointment> getPatientAppointments(Pageable pageable, Long patientId) {
		return appointmentRepository.findByPatient(pageable, patientId);
	}

	public Map<String,List<AppointmentWrapper>> getAllAppointments(Long userId) {
		Map<String,List<AppointmentWrapper>> appointments = new HashMap<>();
		Date curDate = new Date();
		appointments.put("todaysAppointments", getAppointmentsForToday(userId,curDate));
		appointments.put("futureAppointments", getFutureAppointments(userId,curDate));
		appointments.put("recentAppointments", getRecentAppointments(userId,curDate));
		return appointments;
	}
	
	public List<AppointmentWrapper> getAppointmentsForToday(Long userId, Date date) {
		return appointmentRepository.getTodaysAppointments(userId,date).stream().map(apt -> new AppointmentWrapper(apt))
				.collect(Collectors.toList());
	}
	
	public List<AppointmentWrapper> getAllAppointmentsForToday(Date date) {
		return appointmentRepository.getTodaysAllAppointments(date).stream().map(apt -> new AppointmentWrapper(apt))
				.collect(Collectors.toList());
	}
	
	public List<AppointmentWrapper> getFutureAppointments(Long userId, Date date) {
		return appointmentRepository.getFutureAppointments(userId,date).stream().map(apt -> new AppointmentWrapper(apt))
				.collect(Collectors.toList());
	}
	
	public List<AppointmentWrapper> getRecentAppointments(Long userId, Date date) {
		return appointmentRepository.getRecentAppointments(userId,date).stream().map(apt -> new AppointmentWrapper(apt))
				.collect(Collectors.toList());
	}
	
	public Appointment bookPatientAppointment(Appointment apt, Long doctorId) {
		Patient aptPatient = getExistingPatientOrRegister(apt);
		apt.setPatient(aptPatient);
		apt.setUser(userService.getUser(doctorId));
		return appointmentRepository.save(apt);
	}
	
	public Patient getExistingPatientOrRegister(Appointment apt) {
		Patient p = apt.getPatient();
		if(p.getId()!=null) {
			return p;
		} else {
			return patientService.savePatient(p);
		}
	}
	
	public Appointment bookAppointment(Long doctorId, Long patientId) {
		Appointment appointment = new Appointment();
		User doctor = userService.getUser(doctorId);
		Patient patient = null;
		try {
			patient = patientService.getPatientById(patientId);
		}catch(NoSuchElementException ex) {
			patient = new Patient();
			patient.setPatientName("Referred_By_Dr."+doctor.getName());
			patient.setCreatedOn(new Date());
			patient.setModifiedOn(new Date());
			patient = patientService.savePatient(patient);
		}
		appointment.setAppointmentDate(Calendar.getInstance());
		appointment.setPatient(patient);
		appointment.setUser(doctor);
		appointment.setNotes("Referred by other doctor");
		return appointmentRepository.save(appointment);
	}
 }
