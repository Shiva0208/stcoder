package com.info.app.controller;

import java.util.List;
import java.util.NoSuchElementException;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.Hospital;
import com.info.app.model.User;
import com.info.app.response.wrapper.UserWrapper;
import com.info.app.service.HospitalService;
import com.info.app.service.UserService;

@RestController
public class RegistrationAndLoginController {

	@Autowired
	private HospitalService hospitalService;
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/greet", method=RequestMethod.GET)
	public String greet() {
		return "Hi Vivek";
	}
	
	@RequestMapping(value = "/login/{hospitalLoginId}", method = RequestMethod.GET)
	public RestResponse hospitalLogin(@PathVariable String hospitalLoginId) throws ApiException{
		if(verifyHospital(hospitalLoginId)) {
			List<UserWrapper> hospitalUsers = hospitalService.getHospitalUsers(hospitalLoginId);
			return new RestResponse(hospitalUsers, HttpStatus.OK);
		} else {
			throw new ApiException("Invalid hospital id", HttpStatus.UNAUTHORIZED);
		}
	}
	
	@RequestMapping(value = "/registerHospital", consumes=MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	public @ResponseBody RestResponse registerHospital(@RequestBody String hospitalDetailsJson) throws ApiException {
		return new RestResponse(hospitalService.registerHospital(new JSONObject(hospitalDetailsJson)),HttpStatus.OK);
	}
	
	private Boolean verifyHospital(String hospitalLoginId) {
		Boolean isValidHospitalId = Boolean.FALSE;
		try {
			if(hospitalService.getHospitalByLoginId(hospitalLoginId) != null) {
				isValidHospitalId = Boolean.TRUE;
			}
		} catch (NoSuchElementException e) {
			isValidHospitalId = Boolean.FALSE;
		}
		return isValidHospitalId;
	}
	
	
	
	@RequestMapping(value = "/hospitals")
	public List<Hospital> getAll(){
		return hospitalService.getAllHospitals(); 
	}
	
	@RequestMapping(value = "/users")
	public List<User> getAllUsers(){
		return userService.getAllUsers(); 
	}
	
}
