package com.info.app.controller;

import java.util.Date;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.Diagnosis;
import com.info.app.service.DiagnosisService;
import com.info.app.service.TreatmentService;

@RestController
public class DiagnosisController {
	
	@Autowired
	private DiagnosisService diagnosisService;
	
	@Autowired
	private TreatmentService treatmentService;
	
    @GetMapping("/diagnosis/{treatmentId}")
    public RestResponse getDiagnosisByTreatment(@PathVariable Long treatmentId) throws ApiException {
        if(!treatmentService.findById(treatmentId).isPresent()) {
            throw new ApiException("Treatment not found!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    	return new RestResponse(diagnosisService.getByTreatment(treatmentId),HttpStatus.OK);
    }
    
    @PostMapping("/diagnosis/{treatmentId}")
    public RestResponse addDiagnosis(@PathVariable Long treatmentId,
                            @Valid @RequestBody Diagnosis diagnosis) throws ApiException {
         return treatmentService.findById(treatmentId)
	         .map(treatment -> {
	        	 diagnosis.setTreatment(treatment);
	        	 return new RestResponse(diagnosisService.addDiagnosis(diagnosis),HttpStatus.OK);
	         }).orElseThrow(() -> new ApiException("Treatment not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @PutMapping("/diagnosis/{diagnosisId}")
    public RestResponse updateDiagnosis(@PathVariable Long diagnosisId,
    								@Valid @RequestBody Diagnosis updatedDiagnosis) throws ApiException {
        return diagnosisService.findById(diagnosisId)
                .map(diagnosis -> {
                	diagnosis.setDescription(updatedDiagnosis.getDescription());
                	diagnosis.setName(updatedDiagnosis.getName());
                	diagnosis.setModifiedOn(new Date());
                    return new RestResponse(diagnosisService.addDiagnosis(diagnosis),HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("Diagnosis not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @DeleteMapping("/diagnosis/{diagnosisId}")
    public RestResponse deleteDiagnosis(@PathVariable Long diagnosisId) throws ApiException {
        return diagnosisService.findById(diagnosisId)
                .map(diagnosis -> {
                    diagnosisService.deleteDiagnosis(diagnosis);
                    return new RestResponse("Deleted Successfully!",HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("Diagnosis not found!",HttpStatus.INTERNAL_SERVER_ERROR));
    }
}
