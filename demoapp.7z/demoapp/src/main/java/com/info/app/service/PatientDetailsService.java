package com.info.app.service;

import com.info.app.exceptions.ApiException;
import com.info.app.model.*;
import com.info.app.repository.DiagnosisRepository;
import com.info.app.response.wrapper.PatientDetailsWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PatientDetailsService {

    @Autowired
    private DiagnosisRepository diagnosisRepository;

    @Autowired
    private DiagnosisService diagnosisService;

    @Autowired
    private TreatmentService treatmentService;

    @Autowired
    private MedicationService medicationService;

    @Autowired
    private VitalDetailsService vitalDetailService;

    @Autowired
    private BillingService billingService;

    @Autowired
    private BillingItemService billingItemService;

    @Autowired
    private AppointmentService appointmentService;

    @Autowired
    private PatientLabTestService patientLabTestService;

    public PatientDetailsService() {
    }

    public PatientDetailsWrapper saveDetails(PatientDetailsWrapper patientDetails) throws ApiException {
        Appointment p = appointmentService.getAppointmentById(patientDetails.getAppointmentId());
        Treatment t = treatmentService.getTreatmentByAppointment(p.getId());
        PatientDetailsWrapper details = new PatientDetailsWrapper();
        details.setAppointmentId(p.getId());
        details.setVisitedDate(p.getAppointmentDate().getTime());
        if (!CollectionUtils.isEmpty(patientDetails.getDiagnosis())) {
            details.setDiagnosis(saveOrUpdateDiagnosis(patientDetails.getDiagnosis(),t));
        }

        if(!CollectionUtils.isEmpty(patientDetails.getMedications())) {
            details.setMedications(saveOrUpdateMedications(patientDetails.getMedications(), t));
        }

        if(!CollectionUtils.isEmpty(patientDetails.getVitalDetails())) {
            details.setVitalDetails(saveOrUpdateVitals(patientDetails.getVitalDetails(),t));
        }

        if(patientDetails.getBillings()!=null) {
            details.setBillings(saveOrUpdate(patientDetails.getBillings(),t));
        }

        if(patientDetails.getPatientLabTests()!=null) {
            details.setPatientLabTests(saveOrUpdateLabTests(patientDetails.getPatientLabTests(),t));
        }
        return details;
    }

    private Billing saveOrUpdate(Billing billing, Treatment t) {
        List<Billing> billings = billingService.getByTreatment(t.getId());
        Billing b;
        if(!billings.isEmpty()) {
            b = billings.get(0);
            b.getBillingItems().clear();
            b.getBillingItems().addAll(billing.getBillingItems());
            b.getBillingItems().stream().forEach(bi-> {
                bi.setBilling(b);
                billingItemService.addBillingItem(bi);
            });
            return b;
        }else {
           return billingService.addBilling(billing);
        }
    }

    private List<VitalDetails> saveOrUpdateVitals(List<VitalDetails> vitals,Treatment t) {
        return vitals.stream().map(v->{
            if(v.getId()!=null) {
                VitalDetails vitalDetails = vitalDetailService.findById(v.getId()).get();
                vitalDetails.setVital(v.getVital());
                vitalDetails.setDateTime(v.getDateTime()!=null?v.getDateTime(): Calendar.getInstance());
                vitalDetails.setRange(v.getRange());
                vitalDetails.setReading(v.getReading());
                return vitalDetailService.addVitalDetails(vitalDetails);
            } else {
                v.setTreatment(t);
                return vitalDetailService.addVitalDetails(v);
            }
        }).collect(Collectors.toList());
    }

    private List<Medication> saveOrUpdateMedications(List<Medication> medicationList, Treatment treatment) throws ApiException {
        Prescription ps = medicationService.getPrescription(treatment.getId());
        return medicationList.stream().map(md->{
            if(md.getId()!=null) {
                Medication medication = medicationService.findById(md.getId()).get();
                medication.setMedicineName(md.getMedicineName());
                medication.setMorning(md.isMorning());
                medication.setBeforeMeal(md.isBeforeMeal());
                medication.setAfterMeal(md.isAfterMeal());
                medication.setNight(md.isNight());
                medication.setAfterNoon(md.isAfterNoon());
                return medicationService.addMedication(medication);
            } else {
                md.setPrescription(ps);
                return medicationService.addMedication(md);
            }
        }).collect(Collectors.toList());
    }

    private List<PatientLabTest> saveOrUpdateLabTests(List<PatientLabTest> labTests,Treatment treatment) {
        return labTests.stream().map(lt->{
            if(lt.getId()!=null) {
                PatientLabTest test = patientLabTestService.findById(lt.getId()).get();
                test.setTest(lt.getTest());
                test.setPatient(lt.getPatient());
                test.setLabDcotor(lt.getLabDcotor());
                test.setTestResult(lt.getTestResult());
                test.setModifiedOn(new Date());
                return patientLabTestService.addPatientLabTest(test);
            } else {
                lt.setTreatment(treatment);
                return patientLabTestService.addPatientLabTest(lt);
            }
        }).collect(Collectors.toList());
    }

    private List<Diagnosis> saveOrUpdateDiagnosis(List<Diagnosis> diagnosisList,Treatment t) {
        return diagnosisList.stream().map(d->{
            if(d.getId()!=null) {
                Diagnosis diagnosis = diagnosisService.findById(d.getId()).get();
                diagnosis.setName(d.getName());
                diagnosis.setDescription(d.getDescription());
                diagnosis.setModifiedOn(new Date());
                return diagnosisRepository.save(diagnosis);
            } else {
                d.setTreatment(t);
                return diagnosisRepository.save(d);
            }
        }).collect(Collectors.toList());
    }

    public PatientDetailsWrapper getDetails(Long appointmentId) throws ApiException {
        PatientDetailsWrapper patientDetailsWrapper = new PatientDetailsWrapper();
        Appointment p = appointmentService.getAppointmentById(appointmentId);
        if (p == null)
            throw new ApiException("Invalid appointment Id", HttpStatus.NOT_FOUND);
        Treatment t = treatmentService.getTreatmentByAppointment(appointmentId);
        patientDetailsWrapper.setVisitedDate(p.getAppointmentDate().getTime());
        patientDetailsWrapper.setAppointmentId(appointmentId);
        if(t!=null) {
            patientDetailsWrapper.setDiagnosis(diagnosisService.getByAppointment(appointmentId));
            patientDetailsWrapper.setVitalDetails(vitalDetailService.getByTreatment(t.getId()));

            List<Medication> medications = medicationService.getByTreatment(t.getId()) != null ? medicationService.getByTreatment(t.getId()) : null;
            patientDetailsWrapper.setMedications(medications);

            List<PatientLabTest> patientLabTests = patientLabTestService.getByTreatment(t.getId()) !=null ? patientLabTestService.getByTreatment(t.getId()) : null;
            patientDetailsWrapper.setPatientLabTests(patientLabTests);

            Billing b = billingService.getByTreatment(t.getId()) != null ? billingService.getByTreatment(t.getId()).get(0) : null;
            patientDetailsWrapper.setBillings(b);
        }
        return patientDetailsWrapper;
    }
}
