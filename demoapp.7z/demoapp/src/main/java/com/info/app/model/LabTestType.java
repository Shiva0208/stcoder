package com.info.app.model;

public enum LabTestType {
	GENERAL("GENERAL"),
	OBSTERICS("OBSTERICS"),
	SONOGRAPHY("SONOGRAPHY"),
	COLOURDOPPLER("COLOURDOPPLER"),
	ELASTOGRAPHY("ELASTOGRAPHY"),
	X_RAY("X_RAY"),
	ECHO("ECHO");
	
	private String label;
	LabTestType(String label) {
		this.label = label;
	}
	public String getLabel() {
		return label;
	}
}
