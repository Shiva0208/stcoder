package com.info.app.exceptions;

import org.springframework.http.HttpStatus;

public class ApiException extends Exception {

	private static final long serialVersionUID = 1L;
	private String message;
	private HttpStatus httpStatus; 
	
	public ApiException(String message,HttpStatus status) {
		super(message);
		this.message = message;
		this.httpStatus = status;
	}

	public String getMessage() {
		return message;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

}
