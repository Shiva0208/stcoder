package com.info.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.info.app.exceptions.ApiException;
import com.info.app.model.Medication;
import com.info.app.model.Prescription;
import com.info.app.repository.MedicationRepository;

@Service
public class MedicationService {

	@Autowired
	private MedicationRepository repository;
	
	@Autowired
	private TreatmentService treatmentService;

	public Optional<Medication> findById(Long id){
		return repository.findById(id);
	}
	
	public Prescription getPrescription(Long treatmentId) throws ApiException {
		if(!treatmentService.findById(treatmentId).isPresent()) {
			throw new ApiException("No treatment found", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return treatmentService.findById(treatmentId).get().getPrescription();
	}
	
	public Medication addMedication(Medication medication) {
		return repository.save(medication);
	}

	public void deleteMedication(Medication medication) {
		repository.delete(medication);
	}

	public List<Medication> getByTreatment(Long treatmentId) throws ApiException {
		return repository.findByPrescriptionId(getPrescription(treatmentId).getId());
	}

}
