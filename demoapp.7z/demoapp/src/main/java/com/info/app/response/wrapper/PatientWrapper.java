package com.info.app.response.wrapper;

import java.util.Date;

import com.info.app.model.Patient;

public class PatientWrapper {
	private Long patientId;
	private String patientName;
	private Long treatmentId;
	private Long appointmentId;
	private String address;
	private Integer age;
	private Integer weight;
	private String gender;
	private String occupation;
	private String patientType;
	private Long doctorId;
	private String doctorName;
	private Long hospitalId;
	private String hospitalName;
	private String bedNum;
	private String wardName;
	private Date admissionDate;
	private Date dischargeDate;
	
	public PatientWrapper(Patient patient) {
		this.patientId = patient.getId();
		this.patientName = patient.getPatientName();
		this.address = patient.getAddress();
		this.age = patient.getAge();
		this.weight = patient.getWeight();
		this.gender = patient.getGender();
		this.occupation = patient.getOccupation();
		this.patientType = patient.getPatientType().getLabel();
		this.doctorId = patient.getDoctor()!=null? patient.getDoctor().getId():-1;
		this.doctorName = patient.getDoctor()!=null? patient.getDoctor().getName():"";
		this.hospitalId = patient.getDoctor()!=null? patient.getDoctor().getHospital().getId():-1;
		this.hospitalName = patient.getDoctor()!=null? patient.getDoctor().getHospital().getName():"";
		this.bedNum = patient.getBedNum();
		this.wardName = patient.getWard()!=null? patient.getWard().getWardName():"";
		this.admissionDate = patient.getAdmissionDate();
		this.dischargeDate = patient.getDischargeDate();
	}
	public Long getPatientId() {
		return patientId;
	}
	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public Long getTreatmentId() {
		return treatmentId;
	}

	public void setTreatmentId(Long treatmentId) {
		this.treatmentId = treatmentId;
	}

	public Long getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(Long appointmentId) {
		this.appointmentId = appointmentId;
	}

	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Integer getWeight() {
		return weight;
	}
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getPatientType() {
		return patientType;
	}
	public void setPatientType(String patientType) {
		this.patientType = patientType;
	}
	public Long getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Long doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public Long getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(Long hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getBedNum() {
		return bedNum;
	}
	public void setBedNum(String bedNum) {
		this.bedNum = bedNum;
	}
	public String getWardName() {
		return wardName;
	}
	public void setWardName(String wardName) {
		this.wardName = wardName;
	}
	public Date getAdmissionDate() {
		return admissionDate;
	}
	public void setAdmissionDate(Date admissionDate) {
		this.admissionDate = admissionDate;
	}
	public Date getDischargeDate() {
		return dischargeDate;
	}
	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	};

}

