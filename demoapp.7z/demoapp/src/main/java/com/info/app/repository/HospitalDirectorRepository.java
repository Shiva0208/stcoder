package com.info.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.info.app.model.HospitalDirector;

@Repository
public interface HospitalDirectorRepository extends JpaRepository<HospitalDirector, Long> {

}
