package com.info.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.info.app.model.Diagnosis;
import com.info.app.repository.DiagnosisRepository;

@Service
public class DiagnosisService {
	
	@Autowired
	private DiagnosisRepository repository;

	public Optional<Diagnosis> findById(Long id){
		return repository.findById(id);
	}
	
	public Diagnosis addDiagnosis(Diagnosis diagnosis) {
		return repository.save(diagnosis);
	}

	public void deleteDiagnosis(Diagnosis diagnosis) {
		repository.delete(diagnosis);
	}

	public List<Diagnosis> getByTreatment(Long treatmentId) {
		return repository.findByTreatmentId(treatmentId);
	}

	public List<Diagnosis> getByAppointment(Long appointmentId) {
		return repository.getByAppointmentId(appointmentId);
	}
	
}
