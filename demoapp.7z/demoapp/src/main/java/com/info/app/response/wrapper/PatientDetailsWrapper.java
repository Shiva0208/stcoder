package com.info.app.response.wrapper;

import com.info.app.model.*;

import java.util.Date;
import java.util.List;

public class PatientDetailsWrapper {

	private Long appointmentId;
	private Date visitedDate;
	private List<Diagnosis> diagnosis;
	private List<Medication> medications;
	private List<VitalDetails> vitalDetails;
	private List<PatientLabTest> patientLabTests;
	private Billing billings;

    public Long getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(Long appointmentId) {
        this.appointmentId = appointmentId;
    }

    public Date getVisitedDate() {
        return visitedDate;
    }

    public void setVisitedDate(Date visitedDate) {
        this.visitedDate = visitedDate;
    }

    public List<Diagnosis> getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(List<Diagnosis> diagnosis) {
        this.diagnosis = diagnosis;
    }

    public List<Medication> getMedications() {
        return medications;
    }

    public void setMedications(List<Medication> medications) {
        this.medications = medications;
    }

    public List<VitalDetails> getVitalDetails() {
        return vitalDetails;
    }

    public void setVitalDetails(List<VitalDetails> vitalDetails) {
        this.vitalDetails = vitalDetails;
    }

    public Billing getBillings() {
        return billings;
    }

    public void setBillings(Billing billings) {
        this.billings = billings;
    }

    public List<PatientLabTest> getPatientLabTests() {
        return patientLabTests;
    }

    public void setPatientLabTests(List<PatientLabTest> patientLabTests) {
        this.patientLabTests = patientLabTests;
    }
}
