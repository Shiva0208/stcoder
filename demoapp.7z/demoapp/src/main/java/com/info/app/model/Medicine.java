package com.info.app.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

//@Entity(name = "medicine")
public class Medicine {
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	//@Column(name = "id")
	private Long id;
	
	//@Column(name = "name")
	private String name;
	
	//@Column(name = "content")
	private String content;
	
	//@Column(name = "volume")
	private String volume;
	
	//@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	//@Column(name = "created_on")
	private Date createdOn;
	
	//@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	//@Column(name = "modified_on")
	private Date modifiedOn;
	
//	@JsonIgnore
//	@OneToOne(mappedBy = "medicine", cascade = CascadeType.MERGE, fetch = FetchType.LAZY)
//	private Medication medication;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getVolume() {
		return volume;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}
	
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

//	public Medication getMedication() {
//		return medication;
//	}
//
//	public void setMedication(Medication medication) {
//		this.medication = medication;
	//}
	
}
