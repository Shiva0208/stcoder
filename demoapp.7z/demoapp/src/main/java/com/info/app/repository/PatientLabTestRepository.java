package com.info.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.info.app.model.PatientLabTest;

@Repository
public interface PatientLabTestRepository extends JpaRepository<PatientLabTest, Long> {
	List<PatientLabTest> findByTreatmentId(Long treatmentId);
}
