package com.info.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.info.app.model.Appointment;
import com.info.app.model.Treatment;

@Repository
public interface TreatmentRepository extends JpaRepository<Treatment, Long> {

	Treatment findByAppointment(Appointment appointment);

	@Query(value = "select t.* from treatment t, appointment a "
			+ "where t.appointment_id = a.id and a.user_id = :userId and "
			+ "a.patient_id = :patientId order by t.appointment_id desc limit :page, :size", nativeQuery = true)
	List<Treatment> findByPatientAndDoctor(@Param("userId") Long userId, @Param("patientId") Long patientId,
			@Param("page") Integer page, @Param("size") Integer size);

	@Query(value = "select t.* from treatment t,appointment a " +
			"where t.appointment_id = a.id and a.patient_id = :patientId order by a.appointment_date desc limit 1", nativeQuery = true)
    Treatment findByPatient(@Param("patientId") Long patientId);
}
