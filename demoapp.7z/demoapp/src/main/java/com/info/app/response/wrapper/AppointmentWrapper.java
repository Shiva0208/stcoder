package com.info.app.response.wrapper;

import java.util.Date;

import com.info.app.model.Appointment;

public class AppointmentWrapper {
	private Long id;
	private Long treatmentId;
	private Date appointmentDate;
	private Long patientId;
	private String patientName;
	private Long doctorId;
	private String doctorName;
	private String gender;
	private Integer age;
	private Integer weight;
	private String patientType;
	
	public AppointmentWrapper(Appointment appointment) {
		this.id = appointment.getId();
		this.treatmentId = appointment.getTreatment().getId();
		this.appointmentDate = appointment.getAppointmentDate().getTime();
		this.patientId = appointment.getPatient().getId();
		this.patientName = appointment.getPatient().getPatientName();
		this.doctorId = appointment.getUser().getId();
		this.doctorName = appointment.getUser().getName();
		this.gender = appointment.getPatient().getGender();
		this.age = appointment.getPatient().getAge();
		this.weight = appointment.getPatient().getWeight();
		this.patientType = appointment.getPatient().getPatientType().getLabel();
	}
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public Long getTreatmentId() {
		return treatmentId;
	}

	public void setTreatmentId(Long treatmentId) {
		this.treatmentId = treatmentId;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}

	public Long getPatientId() {
		return patientId;
	}

	public void setPatientId(Long patientId) {
		this.patientId = patientId;
	}

	public void setAppointmentDate(Date appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getPatientName() {
		return patientName;
	}
	
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	
	public Long getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(Long doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Integer getWeight() {
		return weight;
	}
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	public String getPatientType() {
		return patientType;
	}
	public void setPatientType(String patientType) {
		this.patientType = patientType;
	}
	
}
