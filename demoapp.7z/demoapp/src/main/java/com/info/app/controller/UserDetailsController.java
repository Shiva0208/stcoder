package com.info.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.User;
import com.info.app.response.wrapper.UserWrapper;
import com.info.app.service.UserService;

@RestController
@RequestMapping("userdetails")
public class UserDetailsController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/registerDoctor/{hospitalId}", method = RequestMethod.POST)
	public RestResponse addDoctor(@RequestBody User newUser, @PathVariable Long hospitalId) throws ApiException {
		return new RestResponse(new UserWrapper(userService.registerDoctor(newUser,hospitalId)), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/addReferralForDoctor/{doctorId}", method = RequestMethod.POST)
	public RestResponse addReferrals(@PathVariable Long doctorId, @RequestBody List<Long> referralIds) {
		userService.saveReferralsForDoctor(doctorId, referralIds);
		return new RestResponse("SUCCESS",HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getMyReferrals/{doctorId}", method = RequestMethod.GET)
	public RestResponse getMyReferrals(@PathVariable Long doctorId) {
		return new RestResponse(userService.getUser(doctorId).getReferrals(),HttpStatus.OK);
	}

	@RequestMapping(value = "/getHospitalDoctors/{hospitalId}", method = RequestMethod.GET)
	public RestResponse getAllHospitalDoctors(@PathVariable Long hospitalId) {
		return new RestResponse(userService.getAllHospitalUsers(hospitalId),HttpStatus.OK);
	}
}
