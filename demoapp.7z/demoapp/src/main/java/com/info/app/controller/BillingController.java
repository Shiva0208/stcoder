package com.info.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.Billing;
import com.info.app.service.BillingService;
import com.info.app.service.TreatmentService;

@RestController
public class BillingController {
	
	@Autowired
	private BillingService billingService;
	
	@Autowired
	private TreatmentService treatmentService;
	
    @GetMapping("/billing/{treatmentId}")
    public RestResponse getDiagnosisByTreatment(@PathVariable Long treatmentId) throws ApiException {
        if(!treatmentService.findById(treatmentId).isPresent()) {
            throw new ApiException("Treatment not found!", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    	return new RestResponse(billingService.getByTreatment(treatmentId),HttpStatus.OK);
    }
    
    @PostMapping("/billing/{treatmentId}")
    public RestResponse addBilling(@PathVariable Long treatmentId,
                            @Valid @RequestBody Billing billing) throws ApiException {
         return treatmentService.findById(treatmentId)
	         .map(treatment -> {
	        	 billing.setTreatment(treatment);
	        	 billing.getBillingItems().forEach(bi->{
	        		 bi.setBilling(billing);
	        	 });
	        	 return new RestResponse(billingService.addBilling(billing),HttpStatus.OK);
	         }).orElseThrow(() -> new ApiException("Treatment not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @PutMapping("/billing/{billingId}")
    public RestResponse updateBilling(@PathVariable Long billingId,
    								@Valid @RequestBody Billing updatedBilling) throws ApiException {
        return billingService.findById(billingId)
                .map(billing -> {
                	billing.getBillingItems().clear();
                	updatedBilling.getBillingItems().forEach(bi->{
      	        		 bi.setBilling(billing);
      	        	 });
                	billing.getBillingItems().addAll(updatedBilling.getBillingItems());
                    return new RestResponse(billingService.addBilling(billing),HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("Billing not found!", HttpStatus.INTERNAL_SERVER_ERROR));
    }
    
    @DeleteMapping("/billing/{billingId}")
    public RestResponse deleteBilling(@PathVariable Long billingId) throws ApiException {
        return billingService.findById(billingId)
                .map(billing -> {
                	billingService.deleteBilling(billing);
                    return new RestResponse("Deleted Successfully!",HttpStatus.OK);
                }).orElseThrow(() -> new ApiException("Billing not found!",HttpStatus.INTERNAL_SERVER_ERROR));
    }

}
