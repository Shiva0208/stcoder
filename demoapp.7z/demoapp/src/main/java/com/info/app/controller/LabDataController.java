package com.info.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.exceptions.ApiException;
import com.info.app.model.LabTest;
import com.info.app.service.LabDataService;

@RestController
@RequestMapping("lab")
public class LabDataController {
	
	@Autowired
	private LabDataService labDataService;

	@RequestMapping(value = "/data", method = RequestMethod.GET)
	public RestResponse getLabData() throws ApiException {
		return new RestResponse(labDataService.getLabData(),HttpStatus.OK);
	}
	
	@RequestMapping(value = "/data", method = RequestMethod.POST)
	public RestResponse addLabData(@RequestBody LabTest labTest) throws ApiException {
		return new RestResponse(labDataService.addLabData(labTest),HttpStatus.OK);
	}
	
	@RequestMapping(value = "/data", method = RequestMethod.PUT)
	public RestResponse editLabData(@RequestBody LabTest labTest) throws ApiException {
		return new RestResponse(labDataService.editLabData(labTest),HttpStatus.OK);
	}
	
	@RequestMapping(value = "/data", method = RequestMethod.DELETE)
	public RestResponse deleteLabData(@RequestBody LabTest labTest) throws ApiException {
		labDataService.deleteLabData(labTest);
		return new RestResponse("SUCCESS",HttpStatus.OK);
	}
	
	@RequestMapping(value = "/data/all", method = RequestMethod.DELETE)
	public RestResponse addAllLabData(@RequestBody List<LabTest> labTests) throws ApiException {
		return new RestResponse(labDataService.addAllLabData(labTests),HttpStatus.OK);
	}
}
