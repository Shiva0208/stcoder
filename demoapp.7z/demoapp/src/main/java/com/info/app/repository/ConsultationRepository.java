package com.info.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.info.app.model.Consultation;

@Repository
public interface ConsultationRepository extends  JpaRepository<Consultation, Long> {
	
	@Query(value = "select c.* from consultation c where c.reffered_by_id = :doctorId", nativeQuery = true)
	public List<Consultation> getRefferedByMe(@Param("doctorId") Long selfId);
	
	@Query(value = "select c.* from consultation c where c.reffered_to_id = :doctorId", nativeQuery = true)
	public List<Consultation> getRefferedToMe(@Param("doctorId") Long selfId);
	
}
