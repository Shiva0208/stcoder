package com.info.app.repository;

public interface MedicineRepository{

}
