package com.info.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.info.app.common.RestResponse;
import com.info.app.service.ConsultationServie;

@RestController
@RequestMapping("consultation")
public class ConsultationController {
	
	@Autowired
	private ConsultationServie consultationService;

	@RequestMapping(value = "/referralsByMe/{doctorId}", method = RequestMethod.GET)
	public RestResponse getRefferredByMe(@PathVariable Long doctorId) {
		return new RestResponse(consultationService.getRefferredByMe(doctorId),HttpStatus.OK);
	}
	
	@RequestMapping(value = "/referralsToMe/{doctorId}", method = RequestMethod.GET)
	public RestResponse getRefferredToMe(@PathVariable Long doctorId) {
		return new RestResponse(consultationService.getRefferredToMe(doctorId),HttpStatus.OK);
	}
	
	@RequestMapping(value = "/refer/{patientId}/{referToDoctorId}/{referByDoctorId}", method = RequestMethod.POST)
	public RestResponse refer(@PathVariable Long patientId, @PathVariable Long referByDoctorId, @PathVariable Long referToDoctorId) {
		consultationService.referDoctor(patientId,referByDoctorId,referToDoctorId);
		return new RestResponse("SUCCESS", HttpStatus.OK);
	}
	
	@RequestMapping(value = "/referrals", method = RequestMethod.GET)
	public RestResponse referrals(@RequestParam Long doctorId) {
		return new RestResponse(consultationService.getAllConsultations(doctorId), HttpStatus.OK);
	}
	
}
